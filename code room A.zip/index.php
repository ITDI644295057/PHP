<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action ="" method="get">
        ชื่อผู้ใช้งาน : <input type = "text" name="username">
        <br>
        รหัสผ่าน : <input type = "passwprd" name="password">
        <br>
        <input type="submit" value = "เข้าสู่ระบบ">
        <br>
        <a href="regis.php">สมัครสมาขิก</a>
</body>
</html>